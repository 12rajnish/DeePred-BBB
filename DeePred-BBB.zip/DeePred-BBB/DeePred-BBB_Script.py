#BBB Permeability prediction using Deep Neural Network

import pandas as pd  
from sklearn.preprocessing import StandardScaler
import subprocess
from keras.models import load_model

path="INPUT THE PATH OF EXTRACTED FOLDER"

def bbb(input_bbb, path):
    
    bbb_data = pd.read_csv(path+"/data.csv")
    sc = StandardScaler()  
    bbb_data = sc.fit_transform(bbb_data)  
    bbb_user_input = sc.transform(input_bbb)
   # model = path+"/DeePredmodel.h5"
    loaded_model = load_model(path+"/DeePredmodel.h5") 
    print("Model loaded")
    prediction = loaded_model.predict(bbb_user_input).round()
    prediction = prediction[:,0].astype (int)
    return prediction
    

subprocess.call(['java', '-jar', 'PaDEL-Descriptor/PaDEL-Descriptor.jar','-descriptortypes', 'PaDEL-Descriptor/descriptors.xml', '-dir', path, '-file', path+'/feature.csv', '-2d', '-fingerprints', '-removesalt', '-detectaromaticity', '-standardizenitro'])
print ("Feature calculated")

input_bbb =pd.read_csv(path+"/feature.csv")
input_bbb = input_bbb.drop(['Name'],axis=1)
prediction=bbb(input_bbb, path)
print (prediction)

print ("Prediction Result :")
for i in range(len(prediction)):
    if (prediction[i] == 1):
        print ('BBB-permeable')
    else:
        print ('BBB-nonpermeable')



        